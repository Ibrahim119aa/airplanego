"use client"

import Component from "../travel-booking"

export default function Page() {
  return <Component />
}
